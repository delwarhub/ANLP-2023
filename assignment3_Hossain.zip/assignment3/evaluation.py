import random

import torch
from torch.nn.functional import softmax

from utils import char_tensor


def bpc(output, target):
    norm = softmax(output, dim=1)
    return torch.log2(norm)[0][target]


def compute_bpc(model, string):
    """
    Given a model and a string of characters, compute bits per character
    (BPC) using that model.

    Args:
        model: RNN-based model (RNN, LSTM, GRU, etc.)
        string: string of characters

    Returns:
        BPC for that set of string.
    """
    ################# STUDENT SOLUTION ################################
    # YOUR CODE HERE
    chunk_len = 200
    file_len = len(string)
    start_index = random.randint(0, file_len - chunk_len -1)
    end_index = start_index + chunk_len + 1
    chunk = string[start_index:end_index]
    inp = char_tensor(chunk[:-1])
    target = char_tensor(chunk[1:])

    hidden, cell = model.init_hidden()
    model.zero_grad()
    loss = 0
    for c in range(chunk_len):
        output, (hidden, cell) = model(inp[c], (hidden, cell))
        loss += bpc(output, target[c].view(1))
    loss = -loss / chunk_len
    return loss
    ###################################################################

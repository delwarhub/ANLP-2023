import torch
import torch.nn as nn


# Here is a pseudocode to help with your LSTM implementation. 
# You can add new methods and/or change the signature (i.e., the input parameters) of the methods.
class LSTM(nn.Module):
    def __init__(self,input_size,hid_size,output_size,layers):
        """Think about which (hyper-)parameters your model needs; i.e., parameters that determine the
        exact shape (as opposed to the architecture) of the model. There's an embedding layer, which needs 
        to know how many elements it needs to embed, and into vectors of what size. There's a recurrent layer,
        which needs to know the size of its input (coming from the embedding layer). PyTorch also makes
        it easy to create a stack of such layers in one command; the size of the stack can be given
        here. Finally, the output of the recurrent layer(s) needs to be projected again into a vector
        of a specified size."""
        ############################ STUDENT SOLUTION ############################
        # YOUR CODE HERE
        super(LSTM, self).__init__()
        self.hidden_dim = hid_size
        self.layers = layers
        self.embedding_size = 100  # Embedding is 100 for first exercise and is not part of construtor parameter.
        # However embedding as parameter of constructor is introduced in Hyperparameter tuning exercise.
        self.input_size = input_size
        self.output_size = output_size
        self.embeddings = nn.Embedding(self.input_size, self.embedding_size)
        self.lstm = nn.LSTM(input_size=self.embedding_size, hidden_size=self.hidden_dim, num_layers=self.layers)
        self.linear = nn.Linear(self.hidden_dim, self.output_size)
        ##########################################################################

    def forward(self,x,state):
        """Your implementation should accept input character, hidden and cell state,
        and output the next character distribution and the updated hidden and cell state."""
        ############################ STUDENT SOLUTION ############################
        # YOUR CODE HERE
        out = self.embeddings(x).view(1,1,-1)
        out, hidden = self.lstm(out,state)
        out = out.contiguous().view(-1, self.hidden_dim)
        out = self.linear(out)
        return out,hidden
        ##########################################################################

    def init_hidden(self):
        """Finally, you need to initialize the (actual) parameters of the model (the weight
        tensors) with the correct shapes."""
        ############################ STUDENT SOLUTION ############################
        # YOUR CODE HERE
        hidden_state = torch.zeros((self.layers,1, self.hidden_dim))
        cell_state = torch.zeros((self.layers,1, self.hidden_dim))
        return hidden_state, cell_state
        ##########################################################################

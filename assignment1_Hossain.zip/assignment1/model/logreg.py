import numpy as np

from model.naivebayes import remove_stop_words, vocab
from utils import test_data


class LogReg:
    def __init__(self, eta=0.01, num_iter=30):
        self.eta = eta
        self.num_iter = num_iter

    def softmax(self, inputs):
        """
        Calculate the softmax for the give inputs (array)
        :param inputs:
        :return:
        """
        total = 0
        temp = []
        prob = []
        for i in range(len(self.weights)):
            temp.insert(i, np.exp(np.dot(inputs, self.weights[i]) + self.bias[i]))
            total += temp[i]
        for i in range(len(self.weights)):
            prob.insert(i, temp[i] / float(total))
        return prob

    def gradient(self, y_, y, x):

        '''
        This function computes gradient using calculated output (y_), actual output(y) and input matrix (x)
        x is matrix which contains data instance wrt their weights.

        "grad" variable is a matrix with rows representing number of classes (2) and column representing
         features(words in Vocabulary).

        It returns improved weights and bias for each features wrt their classes.

        '''
        bias = np.zeros((self.weights.shape[0], 1))
        grad = np.zeros(self.weights.shape)

        for i in range(len(y)):
            if y[i][0] == 1:
                grad[1] += -(1 - y_[i][1]) * x[i]
                bias[1] += -(1 - y_[i][1])
            else:
                grad[0] += y_[i][0] * x[i]
                bias[0] += y_[i][0]
        return grad, bias

    def train(self, X, Y):
        #################### STUDENT SOLUTION ###################
        # weights initialization
        self.num_class = Y.shape[1]
        self.weights = np.zeros((Y.shape[1], X.shape[1]))
        self.bias = np.zeros((Y.shape[1], 1))
        for i in range(self.num_iter):
            ind = np.arange(len(X))
            np.random.shuffle(ind)
            b = np.arange(0, len(X), 100)
            np.append(b, len(X))
            j = 0
            for j in range(len(b) - 1):
                x = X[ind[b[j]:b[j + 1]]]
                y = Y[ind[b[j]:b[j + 1]]]
                prob = np.zeros((len(x), 2))
                prob = self.p(x)
                grad = np.zeros((self.weights.shape))
                biass = np.zeros((self.weights.shape[0], 1))
                (grad, biass) = self.gradient(prob, y, x)
                grad = grad / len(x)
                biass = biass / len(x)
                self.weights[0] = self.weights[0] - self.eta * grad[0]
                self.weights[1] = self.weights[1] - self.eta * grad[1]
                self.bias[0] = self.bias[0] - self.eta * biass[0]
                self.bias[1] = self.bias[1] - self.eta * biass[1]

        return None
        #########################################################

    def p(self, X):
        """
        This function computes probability for each data instance wrt each class.

        "prob" is a matrix of size ( num of data instances X num of classes )
        For our particular case first case represent class "nonoffensive" and second column represent "offensive"
        i.e prob[i][0] is probability for y=0 and prob[i][1] is probability for y=1 where y is actual output and
        offensive means 1.

        """

        # YOUR CODE HERE
        #     TODO:
        #         1) Fill in (log) probability prediction
        ################## STUDENT SOLUTION ########################
        m = self.weights.shape[0]
        n = X.shape[0]
        prob = np.zeros((n, m))
        for i in range(n):
            prob[i] = self.softmax(X[i])
        return prob
        ############################################################

    def predict(self, X):

        """
               This function predicts the class to which given data instance belongs to.
               We compare the calculated probability of given instance among all classes.
               Class with max probability is the output.

               It also calculates F_1 score.
               """
        # YOUR CODE HERE
        #     TODO:
        #         1) Replace next line with prediction of best class
        ####################### STUDENT SOLUTION ####################

        (x_test, y_test) = featurize(X)
        prob = self.p(x_test)
        result = []
        for i in range(len(x_test)):
            if prob[i][0] > prob[i][1]:
                result.insert(i, 0)
            else:
                result.insert(i, 1)
        tp = 0
        tn = 0
        fn = 0
        fp = 0
        for i in range(len(y_test)):
            if y_test[i][0] == result[i]:
                if result[i] == 1:
                    tp += 1
                else:
                    tn += 1
            else:
                if result[i] == 1:
                    fp += 1
                else:
                    fn += 1
        pr = tp / (tp + fp)
        r = tp / (tp + fn)
        f1 = 2 * pr * r / (pr + r)
        acc = (tp + tn) / (tp + tn + fn + fp)
        print(f'Accuracy: {acc}')
        print("F_1 score is: " + str(f1))

        return None
        #############################################################


def buildw2i(data):
    """
    Create indexes for 'featurize()' function.

    Args:
        vocab: vocabulary constructed from the training set.

    Returns:
        Dictionaries with word as the key and index as its value.
    """
    # YOUR CODE HERE
    #################### STUDENT SOLUTION ######################
    vocab = []
    for word in data:
        vocab += word[0]
    vocab = [word.lower() for word in vocab]
    vocab = remove_stop_words(vocab)
    return set(vocab)
    ############################################################


def featurize(data):
    """
    Convert data into X and Y where X is the input and
    Y is the label.

    Args:
        data: Training or test data.
        train_data: Reference data to build vocabulary from.

    Returns:
        Matrix X and Y.
    """
    # YOUR CODE HERE
    ##################### STUDENT SOLUTION #######################
    vocab = list(buildw2i(data))
    X = np.array([[0 for j in range(len(vocab))], ] * len(data))
    i = 0
    for obj in data:
        tweet = [word.lower() for word in list(obj[0])]
        j = 0
        for word in vocab:
            if word in tweet:
                X[i][j] = 1
            else:
                X[i][j] = 0
            j += 1
        i += 1
    Y = np.array([[0, 1], ] * len(data))
    for i in range(len(data)):
        if data[i][1] == 'offensive':
            Y[i] = [1, 0]
    return X, Y

##############################################################

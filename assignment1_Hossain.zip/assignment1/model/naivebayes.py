import math
import operator
from nltk.corpus import stopwords


class NaiveBayes(object):
    ######################### STUDENT SOLUTION #########################
    # YOUR CODE HERE
    C = []  # Classes : It is list of classes in dataset
    V = []  # Vocabulary : It is list of unique tokens in dataset
    log_prior = {}  # It stores log_prior wrt to class, eg: {'class1':value,'class2':value,....}
    log_likelihood = {}  # It stores log_likelihood wrt to class, eg: {'class1':{word1:value,word2:value,..},'class2':{},....}
    Bi = {}

    def __init__(self):
        """Initialises a new classifier."""
        self.tp = 0  # True Positive
        self.tn = 0  # True Negative
        self.fp = 0  # False Positive
        self.fn = 0  # False Negative

    ####################################################################

    def predict(self, x):
        """Predicts the class for a document.

        Args:
            x: A document, represented as a list of words.

        Returns:
            The predicted class, represented as a string.
        """
        ################## STUDENT SOLUTION ########################
        # YOUR CODE HERE

        sum_ = {}  # Variable to store sum of log probability as { 'class1': value, 'class2': value , ....}
        x = remove_unknown(self.V, x)  # removes words which are not present in Vocabulary but in test document
        x = [word.lower() for word in x]
        for cl in self.C:
            tot = self.log_prior[cl]
            for word in x:
                if word in self.V:
                    tot = tot + self.log_likelihood[cl][word]
            sum_[cl] = tot
            tot = 0

        if len(sum_) > 0:
            return max(sum_.items(), key=operator.itemgetter(1))[0]
        else:
            return None  # Returns None if remove_unkown() returns a empty list

    ############################################################

    @classmethod
    def train(cls, data, k=1):
        """Train a new classifier on training data using maximum
        likelihood estimation and additive smoothing.

        Args:
            cls: The Python class representing the classifier.
            data: Training data.
            k: The smoothing constant.

        Returns:
            A trained classifier, an instance of `cls`.
        """
        ##################### STUDENT SOLUTION #####################
        # YOUR CODE HERE
        num_of_docs = len(data)  # total number of tweets in our case
        cls.C = set([word[1] for word in data])  # set of classes
        cls.V = vocab(data)  # set of unique words in training data
        cls.V = remove_stop_words(cls.V)
        cls.V = set([word.lower() for word in cls.V])
        words_in_class = {}
        for cl in cls.C:
            num_of_docs_in_c = count_for_class(data, cl)
            cls.log_prior[cl] = math.log(num_of_docs_in_c / num_of_docs)
            words_in_class[cl] = (vocab_for_class(data, cl))
            words_in_class[cl][0] = remove_stop_words(words_in_class[cl][0])
            words_in_class[cl][1] = remove_stop_words(list(words_in_class[cl][1]))
            words_in_class[cl][0] = [word.lower() for word in words_in_class[cl][0]]
            words_in_class[cl][1] = [word.lower() for word in words_in_class[cl][1]]
            count = {}
            cls.log_likelihood[cl] = {}
            for word in cls.V:
                count[word] = words_in_class[cl][0].count(word)
                vc_class_doc = len(words_in_class[cl][1]) + k * len(cls.V)
                cls.log_likelihood[cl][word] = math.log((count[word] + k) / vc_class_doc)
        return cls()
        ############################################################


def remove_unknown(train_vocab, test_vocab):
    """
    It removes the words which are present in testing set but not
    in training set.

    Parameters
    ----------
    train_vocab : vocabulary of training set
    test_vocab : vocabulary of testing set

    Returns
    -------
    test_vocab : modified testing vocabulary

    """
    x = set(test_vocab)
    x = set(train_vocab).intersection(x)
    for word in test_vocab:
        if word not in x:
            test_vocab = list(filter(lambda w: w != word, test_vocab))
    return test_vocab


def remove_stop_words(wordlist):
    """
    It removes stop words like the,is,could,was,....

    Parameters
    ----------
    wordlist : list of words

    Returns
    -------
    vocab : modified list of words

    """
    vocab = [word for word in wordlist if word not in stopwords.words('english')]
    return vocab


def vocab_for_class(data, class_name):
    """
    This function creates vocabulary for a particular class and returns
    a list of words in a class and set of unique words in that class

    Parameters
    ----------
    data : List of docs with class
        DESCRIPTION.
    class_name : string.


    Returns
    -------
    list


    """
    vocab = []
    for word in data:
        if word[1] == class_name:
            vocab += word[0]
    return [vocab, set(vocab)]


def vocab(data):
    """
    This function creates vocabulary set for a given Document

    Parameters
    ----------
    data : list of documents with labelled classes

    Returns
    -------
    set of unique words in set of Documents

    """
    vocab = []
    for word in data:
        vocab += word[0]
    return set(vocab)


def count_for_class(data, class_name):
    """
    This function returns number of docs(tweets) with respect
    to a given input class.

    Parameters
    ----------
    data : List of docs with class
        DESCRIPTION.
    class_name : string.

    Returns
    -------
    count_of_class : int

    """
    count_of_class = 0
    for datum in data:
        if datum[1] == class_name:
            count_of_class += 1
    return count_of_class


def features1(data, k=1):
    """
    Your feature of choice for Naive Bayes classifier.

    Args:
        data: Training data.
        k: The smoothing constant.

    Returns:
        Parameters for Naive Bayes classifier, which can
        then be used to initialize `NaiveBayes()` class
    """
    ###################### STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    '''
        Negative words vocab is used as a feature after filtering out some offensive words (definitely not an exhaustive list)
        from data set. This feature is chosen due to excessive use of offensive words which most of the time comes from a offensive 
        tweets. So this parameter can play an important role to classify tweets.
    '''
    neg_vocab = ['died', 'aggressor', 'terrifying', 'Isis', 'hunting', 'Savage', 'Islamofascim', 'non-believers',
                 'genocidal', 'antisemitism', 'communists', 'Insane', 'pedo', 'bitchy', 'harassed', 'dying',
                 'Islamofascist', 'wars', 'Destruction',
                 'smackem', 'fucktards', 'monsters', 'gross', 'crucify', 'over-sensitive', 'Crucifixion', 'psychopaths',
                 'feminist', 'feminazi',
                 'HATE', 'Crimes', 'mocks', 'ignorant', 'murders', 'hitting', 'rapists', '#IDontNeedFeminism', 'frauds',
                 'punch', 'hoes', 'snobby',
                 'steal', 'stripper', 'kickass', 'brutal', 'harassment', 'execute', 'Insult', 'sewers', 'behead',
                 'damn',
                 '#FuckOff', 'raped',
                 '#Islamists', 'asshole', 'rats', 'violence', 'phony', 'chick', 'danger', 'stole', 'clowns',
                 '#feminism',
                 'fools', 'Gags', 'Nazism',
                 'jihadis', 'atheism', 'morons', 'filthy', 'rant', 'inferior', 'Pigs', 'annoying', 'burnt', 'monger',
                 'faggot', '#Notsexist', 'STFU',
                 '#sexism', 'FUCKING', 'cocks', 'grossly', 'tits', 'gruesome', 'butchers', 'terrorism', 'Trashy',
                 'hateful',
                 'useless', 'semen',
                 'dumbass', 'garbage', 'Hatemongers', 'punching', 'kills', 'cum', 'Satan', 'boobs', 'sexual',
                 'Terrorists',
                 'femininity', 'Jihad',
                 '#Bitches', 'gays', 'hater', 'arrogant', 'egomaniac', 'fat', 'fatty', 'hatered', 'Nazi', 'trashy',
                 'rapist', 'fuckin', 'fascist', 'Idiots',
                 'jihadists', 'grabbing', 'stalk', 'HOT', 'raping', 'faggots', 'dickless', 'murderer', 'sucking',
                 'fucker',
                 'horrible', 'shameful', 'fuck', 'Stalked', 'sassy', 'mantears', 'Islamofasicsm', 'maniacs', 'Sewer',
                 'Feminazi', 'nude', 'weaker', 'fucking', 'swine', 'shits', 'arse', 'BITCHES', 'Bitch', 'dickweed',
                 'pedophelia', 'cocksucker', 'fetish', 'sucks', 'chicks', 'DUMB', 'nigger', '#YouSuck', 'SHUTUP',
                 'shiting',
                 'horny', 'nigga', 'dick', 'slaves', 'Islamolunatic', '#IslamLOVESWomen', 'killer', 'butts', 'Hoes',
                 'crap',
                 'penis', 'hating', 'vaginas', 'stab', 'hatred',
                 'pedophile', 'bigotry', 'barbarity', 'scum', '#killerblondes']

    neg_vocab = set([word.lower() for word in neg_vocab])

    def bigrams(data, cl):
        '''
        This function creates bigram for with respect to their class.
        It returns a dictionary which contain bigram list for all the classes in data set
        e.g in our case {"offensive":[],"nonoffensive"[]}
        '''

        bigrams_in_corpus = {}
        for c in cl:
            bigrams_in_corpus[c] = []
            for sent in data:
                if (sent[1] == c):
                    sent[0].insert(0, "<s>")
                    sent[0].insert(len(sent[0]), "</s>")
                    bigrams_in_corpus[c] += [(sent[0][i].lower(), sent[0][i + 1].lower()) for i in
                                             range(len(sent[0]) - 1)]

        return bigrams_in_corpus

    def bigrams_info(bigrams, cl):
        '''
        This function calculate some information about bigram.
        1. It creates unique set of bigrams for each class, here  uniq_bi
        2. It combines all unique bigrams into one variabe, uniq
        3. It computes frequency of each bigram in its respective class, bi_freq
        4. It combines frequency list from each class into one variable, uniq_freq
        and finally returns uniq_freq and sorted_freq

        '''
        uniq = []
        uniq_bi = {}
        bi_freq = {}
        uniq_freq = {}
        sorted_freq = {}
        for c in cl:
            uniq_bi[c] = list(set(bigrams[c]))
            uniq += uniq_bi[c]
            bi_freq[c] = {bi: bigrams[c].count(bi) for bi in uniq_bi[c]}
            sorted_freq[c] = {word: value for word, value in
                              sorted(bi_freq[c].items(), key=lambda item: item[1], reverse=True)}

        uniq = list(set(uniq))
        uniq_freq = {bi: 0 for bi in uniq}
        for c in cl:
            for bi, value in sorted_freq[c].items():
                uniq_freq[bi] += value
        return uniq_freq, sorted_freq

    ##################################################################


def features2(data, k=1):
    """
    Your feature of choice for Naive Bayes classifier.

    Args:
        data: Training data.
        k: The smoothing constant.

    Returns:
        Parameters for Naive Bayes classifier, which can
        then be used to initialize `NaiveBayes()` class
    """
    ###################### STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    Bi = {}

    return None
    ##################################################################

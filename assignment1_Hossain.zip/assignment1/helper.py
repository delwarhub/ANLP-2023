import matplotlib.pyplot as plt
import numpy as np

from model.naivebayes import NaiveBayes, features1, features2
from model.logreg import LogReg, featurize
from evaluation import accuracy, f_1
from utils import train_data


def train_smooth(train_data, test_data):
    # YOUR CODE HERE
    #     TODO:
    #         1) Re-train Naive Bayes while varying smoothing parameter k,
    #         then evaluate on test_data.
    #         2) Plot a graph of the accuracy and/or f-score given
    #         different values of k and save it, don't forget to include
    #         the graph for your submission.

    ######################### STUDENT SOLUTION #########################
    acc = []  # accuracy list
    f1 = []  # f1 score list
    klist = [i / 100 for i in range(1, 100)]  # list of k values ranges 0 to 1 with step of 0.01

    for k in klist:
        nb = NaiveBayes.train(train_data, k)
        acc.append(accuracy(nb, test_data))
        f1.append(f_1(nb))

    plt.plot(acc, f1)
    plt.ylabel('F_1 score')
    plt.xlabel('Accuracy')
    plt.show()
    plt.savefig("plot1.png")
    plt.plot(klist, f1)
    plt.ylabel('F_1 score')
    plt.xlabel('Laplace Smoothing Constant (k)')
    plt.show()
    plt.savefig("plot2.png")
    plt.plot(klist, acc)
    plt.ylabel('Accuracy')
    plt.xlabel('Laplace Smoothing Constant (k)')
    plt.show()
    plt.savefig("plot3.png")
    ####################################################################


def train_feature_eng(train_data, test_data):
    # YOUR CODE HERE
    #     TODO:
    #         1) Improve on the basic bag of words model by changing
    #         the feature list of your model. Implement at least two
    #         variants using feat
    #
    #
    #         ure1 and feature2
    ########################### STUDENT SOLUTION ########################
    pass
    #####################################################################


def train_logreg(X, Y):
    # YOUR CODE HERE
    #     TODO:
    #         1) First, assign each word in the training set a unique integer index
    #         with `buildw2i()` function (in model/logreg.py, not here)
    #         2) Now that we have `buildw2i`, we want to convert the data into
    #         matrix where the element of the matrix is 1 if the corresponding
    #         word appears in a document, 0 otherwise with `featurize()` function.
    #         3) Train Logistic Regression model with the feature matrix for 10
    #         iterations with default learning rate eta and L2 regularization
    #         with parameter C=0.1.
    #         4) Evaluate the model on the test set.
    ########################### STUDENT SOLUTION ########################
    num_class = Y.shape[1]
    eta = 0.01
    weights = np.zeros((Y.shape[1], X.shape[1]))
    bias = np.zeros((Y.shape[1], 1))
    for i in range(10):
        ind = np.arange(len(X))
        np.random.shuffle(ind)
        b = np.arange(0, len(X), 100)
        np.append(b, len(X))
        j = 0
        for j in range(len(b) - 1):
            x = X[ind[b[j]:b[j + 1]]]
            y = Y[ind[b[j]:b[j + 1]]]
            prob = np.zeros((len(x), 2))
            prob = p(x, weights,bias)
            grad = np.zeros((weights.shape))
            biass = np.zeros((weights.shape[0], 1))
            (grad, biass) = gradient(prob, y, x, weights)
            grad = grad / len(x)
            biass = biass / len(x)
            weights[0] = weights[0] - eta * grad[0]
            weights[1] = weights[1] - eta * grad[1]
            bias[0] = bias[0] - eta * biass[0]
            bias[1] = bias[1] - eta * biass[1]

    return None


def gradient(y_, y, x, weights):
    '''
        This function computes gradient using calculated output (y_), actual output(y) and input matrix (x)
        x is matrix which contains data instance wrt their weights.

        "grad" variable is a matrix with rows representing number of classes (2) and column representing
         features(words in Vocabulary).

        It returns improved weights and bias for each features wrt their classes.

        '''
    bias = np.zeros((weights.shape[0], 1))
    grad = np.zeros(weights.shape)

    for i in range(len(y)):
        if y[i][0] == 1:
            grad[1] += -(1 - y_[i][1]) * x[i]
            bias[1] += -(1 - y_[i][1])
        else:
            grad[0] += y_[i][0] * x[i]
            bias[0] += y_[i][0]
    return grad, bias


def p(X, weights,bias):
    """
        This function computes probability for each data instance wrt each class.

        "prob" is a matrix of size ( num of data instances X num of classes )
        For our particular case first case represent class "nonoffensive" and second column represent "offensive"
        i.e prob[i][0] is probability for y=0 and prob[i][1] is probability for y=1 where y is actual output and
        offensive means 1.

        """

    # YOUR CODE HERE
    #     TODO:
    #         1) Fill in (log) probability prediction
    ################## STUDENT SOLUTION ########################
    m = weights.shape[0]
    n = X.shape[0]
    prob = np.zeros((n, m))
    for i in range(n):
        prob[i] = softmax(X[i],weights, bias)
    return prob


def softmax(inputs, weights, bias):
    """
        Calculate the softmax for the give inputs (array)
        :param inputs:
        :return:
        """
    total = 0
    temp = []
    prob = []
    for i in range(len(weights)):
        temp.insert(i, np.exp(np.dot(inputs, weights[i]) + bias[i]))
        total += temp[i]
    for i in range(len(weights)):
        prob.insert(i, temp[i] / float(total))
    return prob
#####################################################################

import random

from utils import test_data


def accuracy(classifier, data):
    """Computes the accuracy of a classifier on reference data.
    Args:
        classifier: A classifier.
        data: Reference data.

    Returns:
        The accuracy of the classifier on the test data, a float.
    """
    ##################### STUDENT SOLUTION #########################
    # YOUR CODE HERE
    for d in data:
        tweet = d[0]
        actual = d[1]
        predicted = classifier.predict(tweet)
        if predicted is None:
            continue

            # Some document(tweets) might be empty after removing unknown and stop words, in that case predict() returns None
        # and continue to next document(tweet)

        if actual == predicted:
            if predicted == 'offensive':
                classifier.tp += 1
            else:
                classifier.tn += 1
        else:
            if predicted == 'offensive':
                classifier.fp += 1
            else:
                classifier.fn += 1
    return (classifier.tp + classifier.tn) / (classifier.tp + classifier.tn + classifier.fn + classifier.fp)

    ################################################################


def f_1(classifier):
    """Computes the F_1-score of a classifier on reference data.

    Args:
        classifier: A classifier.

    Returns:
        The F_1-score of the classifier on the test data, a float.
    """
    ##################### STUDENT SOLUTION #########################

    # YOUR CODE HERE
    precision = classifier.tp / (classifier.tp + classifier.fp)
    recall = classifier.tp / (classifier.tp + classifier.fn)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1
    ################################################################


class TestClassifier:
    """
    This class is just for testing f_1 and accuracy function.
    """

    def __init__(self):
        self.tp = 0
        self.tn = 0
        self.fp = 0
        self.fn = 0

    def predict(self, x):
        """

        This function randomly selects a class for any given input.

        """
        a = random.randint(0, 2)
        if a == 0:
            return 'offensive'
        elif a == 1:
            return 'nonoffensive'
        else:
            return None


obj = TestClassifier()
print("Accuracy: ", accuracy(obj, test_data[:100]))
print("F_1 score", f_1(obj))

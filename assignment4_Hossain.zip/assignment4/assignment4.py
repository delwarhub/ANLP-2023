import argparse

import nltk
from nltk.tree import Tree

from model.parser import parse, count
from model.recognizer import recognize

GRAMMAR_PATH = './data/atis-grammar-cnf.cfg'


def main():
    parser = argparse.ArgumentParser(
        description='CKY algorithm'
    )

    parser.add_argument(
        '--structural', dest='structural',
        help='Derive sentence with structural ambiguity',
        action='store_true'
    )

    parser.add_argument(
        '--recognizer', dest='recognizer',
        help='Execute CKY for word recognition',
        action='store_true'
    )

    parser.add_argument(
        '--parser', dest='parser',
        help='Execute CKY for parsing',
        action='store_true'
    )

    parser.add_argument(
        '--count', dest='count',
        help='Compute number of parse trees from chart without \
              actually computing the trees (Extra Credit)',
        action='store_true'
    )

    args = parser.parse_args()

    # load the grammar
    grammar = nltk.data.load(GRAMMAR_PATH)
    # load the raw sentences
    s = nltk.data.load("grammars/large_grammars/atis_sentences.txt", "auto")
    # extract the test sentences
    t = nltk.parse.util.extract_test_sentences(s)

    if args.structural:
        # YOUR CODE HERE
        #     TODO:
        #         1) Like asked in the instruction, derive at least two sentences that
        #         exhibit structural ambiguity and indicate the different analyses
        #         (at least two per sentence) with a syntactic tree.
        t1 = nltk.Tree.fromstring('(S (NP (She)) (VP (ran)))')
        t1.pretty_print()

        # Time flies like an arrow
        t2 = Tree.fromstring('(S (NP(NNP(Time))) (VP( (VBZ (flies)) (PP((IN(like)) (NP( (DT(an)) (NN(arrow)))))))))')
        t2.pretty_print()

        t21 = Tree.fromstring('(S ( NP ( NN (Time)) (NNS (flies)) ) (VP( (VBZ (like)) (NP( (DT(an)) (NN(arrow)))))))')
        t21.pretty_print()

        # Lyndia walks in the garden with a tree
        t3 = Tree.fromstring(
            '(S ( NP ( NNP (Lyndia))) (VP (VBZ (walks)) (PP (IN (in)) (NP (NP (DT (the)) (NN (garden)) ) (PP (IN (with)) (NP (DT (a)) (NN (tree)))) ) ) ))')
        t3.pretty_print()

        t31 = Tree.fromstring(
            '(S ( NP ( NNP (Lyndia))) (VP (VBZ (walks)) (PP (IN (in)) (NP (NP (DT (the)) (NN (garden)) ) ))) (PP (IN (with)) (NP (DT (a)) (NN (tree)))) )')
        t31.pretty_print()

    elif args.recognizer:
        # YOUR CODE HERE
        #     TODO:
        #         1) Provide a list of grammatical and ungrammatical sentences (at least 10 each)
        #         and test your recognizer on these sentences.

        grammatical = t[20:30]
        ungrammatical = t[61:71]

        for sents in grammatical:
            val = recognize(grammar, sents[0])
            if val:
                print("{} is in the language of CFG.".format(sents))
            else:
                print("{} is not in the language of CFG.".format(sents))

        for sents in ungrammatical:
            val = recognize(grammar, sents)
            if val:
                print("{} is in the language of CFG.".format(sents))
            else:
                print("{} is not in the language of CFG.".format(sents))

    elif args.parser:
        # We test the parser by using ATIS test sentences.
        print("ID\t Predicted_Tree\tLabeled_Tree")
        for idx, sents in enumerate(t):
            tree = parse(grammar, sents[0])
            print("{}\t {}\t \t{}".format(idx, len(tree), sents[1]))

        # YOUR CODE HERE
        #     TODO:
        #         1) Choose an ATIS test sentence with a number of parses p
        #         such that 1 < p < 5. Visualize its parses. You can use `draw` 
        #         method to do this.
        def build_Tree(root):
            curr = root[1]  # root is like (0,X) where X belongs to set of non-terminals
            # now X is new root and using lookup we will find its children.
            for item in lookup[curr]:
                if root[0] in item[0]:
                    # X can have multiple values in lookup, so it uses the index to identify the corresponding child wrt to Start symbol
                    break
            left = (item[0][0], item[1][
                0])  # Retrieve information of left child of X as (i,Y) where i is integer and Y is non-terminal
            if len(item[1]) != 1:  # we check if X is not the rule for terminal like X <- 'the'
                right = (item[0][1], item[1][1])  # Retrieve information of right child of X as (i,Y)
                left = Tree(left[1], build_Tree(left))  # Recurssively update left child and build left side tree
                right = Tree(right[1], build_Tree(right))  # Recurssively update right child and build right side tree
                return [left, right]  # List of left and right children is returned
            else:
                return [left[1]]  # list containing terminal is returned

        sent = t[52][0]
        L = len(sent)
        table, lookup = recognize(sent)
        curr = grammar.start()
        tree = [item for item in lookup[curr] if item[0] == (0, L)]  # Candidate Trees

        trees = []
        for item in tree:
            left = (0, item[1][0])
            right = (L, item[1][1])
            left = Tree(left[1], build_Tree(left))
            right = Tree(right[1], build_Tree(right))
            trees.append(Tree('S', [left, right]))

    elif args.count:
        print("ID\t Predicted_Tree\tLabeled_Tree")
        for idx, sents in enumerate(t):
            num_tree = count(grammar, sents[0])
            print("{}\t {}\t \t{}".format(idx, num_tree, sents[1]))


if __name__ == "__main__":
    main()

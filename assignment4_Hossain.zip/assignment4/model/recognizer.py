from collections import defaultdict
from typing import List

import nltk


def recognize(grammar: nltk.grammar.CFG, sentence: List[str]) -> bool:
    """
    Recognize whether a sentence in the language of grammar or not.

    Args:
        grammar: Grammar rule that is used to determine grammaticality of sentence.
        sentence: Input sentence that will be tested.

    Returns:
        truth_value: A bool value to determine whether if the sentence
        is in the grammar provided or not.
    """
    # YOUR CODE HERE
    #     TODO:
    #         1) Implement the CKY algorithm and use it as a recognizer.

    ############################ STUDENT SOLUTION ###########################
    table = defaultdict(list)  # It stores non terminal (production of a rule) as
    # value and their location in matrix as key eg: {(0,1):DT,...} for DT <- 'the'
    for i in range(1, len(sentence) + 1):
        for rule in grammar.productions():
            if sentence[i - 1] in rule.rhs():
                # Filling main diagonal of matrix using non-terminal of each words
                table[(i - 1, i)].append(rule.lhs())
                print(table)

        for j in range(i - 2, -1, -1):
            for k in range(j + 1, i):
                for rule in grammar.productions():
                    if len(rule.rhs()) == 2:
                        if rule.rhs()[0] in table[(j, k)] and rule.rhs()[1] in table[(k, i)]:
                            # saving production of each rule whose RHS matches corresponding locations.
                            table[(j, i)].append(rule.lhs())
                            print(table)

    # If top right corner of matrix contains Start Symbol then sentence is recognised successfully
    if grammar.start() in table[(0, len(sentence))]:
        print(' '.join(sentence) + ' : in CFG')
    else:
        print(' '.join(sentence) + ' : not in CFG')
    return table
    #########################################################################

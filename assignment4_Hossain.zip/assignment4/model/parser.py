from collections import defaultdict
from typing import Set, List

import nltk


def parse(grammar: nltk.grammar.CFG, sentence: List[str]) -> Set[nltk.ImmutableTree]:
    """
    Check whether a sentence in the language of grammar or not. If it is, parse it.

    Args:
        grammar: Grammar rule that is used to determine grammaticality of sentence.
        sentence: Input sentence that will be tested.

    Returns:
        tree_set: Set of generated parse trees.
    """
    # YOUR CODE HERE
    #     TODO:
    #         1) Extend your CKY recognizer into a parser by adding backpointers. You
    #         should extract the set of all parse trees from the backpointers in the chart.
    #         2) Note that only 'ImmutableTree` can be used as elements of Python sets.
    ############################# STUDENT SOLUTION ##################################
    table = defaultdict(list)
    lookup = defaultdict(list)  # it stores non terminal (production of rule) as key and a tuple of RHS of rule and
    # corresponding location of non-terminal in table variable
    # eg: { DT:( (0,1),('the',) ) , ... } for rule DT <- 'the'
    for i in range(1, len(sentence) + 1):
        for rule in grammar.productions():
            if sentence[i - 1] in rule.rhs():
                table[(i - 1, i)].append(rule.lhs())
                lookup[rule.lhs()].append(((i - 1, i), rule.rhs()))
        for j in range(i - 2, -1, -1):
            for k in range(j + 1, i):
                for rule in grammar.productions():
                    if rule.rhs()[0] in table[(j, k)] and rule.rhs()[1] in table[(k, i)]:
                        table[(j, i)].append(rule.lhs())
                        lookup[rule.lhs()].append(((j, i), rule.rhs()))
    return table, lookup
    #################################################################################


def count(grammar: nltk.grammar.CFG, sentence: List[str]) -> int:
    """
    Compute the number of parse trees without actually computing the parse tree.

    Args:
        grammar: Grammar rule that is used to determine grammaticality of sentence.
        sentence: Input sentence that will be tested.

    Returns:
        tree_count: Number of generated parse trees.
    """
    ############################# STUDENT SOLUTION ##################################
    pass
    #################################################################################

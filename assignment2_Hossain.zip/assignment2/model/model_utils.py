import numpy as np
import numpy.typing as npt
from typing import Tuple, List, Set
import re


def bag_of_words_matrix(sentences: List[str]) -> npt.ArrayLike:
    """
    Convert the dataset into V x M matrix.
    """
    ############################# STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    tokens_reg = re.compile(r"[\w']+|[.,!?;]")
    tokens = []  # this list will contain tokens with punctuation seperated eg: "help?" is stored as "help" , "?"
    for word in sentences:
        tokens += tokens_reg.findall(word)
    vocab = set([word.lower() for word in tokens if word not in [".", ",", "!", "?", ";", "[", "]"]])
    m = len(sentences)  # number of examples
    v = len(vocab)  # vocabulary size
    bow = np.zeros((v, m))
    for i in range(v):
        word = list(vocab)[i]
        for j in range(m):
            if word in sentences[j]:

                bow[i][j] = 1
            else:
                bow[i][j] = 0
    return bow, vocab
    #########################################################################


def labels_matrix(data: Tuple[List[str], Set[str]], unique_intent) -> npt.ArrayLike:
    """
    Convert the dataset into K x M matrix.
    """
    ############################# STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    k = len(unique_intent)
    m = len(data)
    labeled = np.zeros((k, m))
    for i in range(k):
        cls = list(unique_intent)[i]
        for j in range(m):
            if (cls == data[j]):

                labeled[i][j] = 1
            else:
                labeled[i][j] = 0

    return labeled
    #########################################################################


def softmax(x: npt.ArrayLike) -> npt.ArrayLike:
    """
    Softmax function.
    """
    ############################# STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    x = x.astype(float)
    if x.ndim == 1:
        return np.exp(x) / np.sum(np.exp(x))
    elif x.ndim == 2:
        result = np.zeros_like(x)
        M, N = x.shape
        for n in range(N):
            S = np.sum(np.exp(x[:, n]))
            result[:, n] = np.exp(x[:, n]) / S
        return result
    else:
        print("The input array is not 1- or 2-dimensional.")
    #########################################################################


def relu(z: npt.ArrayLike) -> npt.ArrayLike:
    """
    Rectified Linear Unit function.
    """
    ############################# STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    return np.maximum(0, z)
    #########################################################################


def relu_prime(z: npt.ArrayLike) -> npt.ArrayLike:
    """
    First derivative of ReLU function.
    """
    ############################# STUDENT SOLUTION ##########################
    # YOUR CODE HERE
    return np.where(z <= 0, 0, 1)
    #########################################################################

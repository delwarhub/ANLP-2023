import numpy as np
import numpy.typing as npt

from model.model_utils import softmax, relu, relu_prime
from typing import Tuple


class NeuralNetwork(object):
    def __init__(
        self, 
        input_size: int,
        hidden_size: int, 
        num_classes: int,
        vocab_size: int,
        seed: int = 1,

    ):
        """
        Initialize neural network's weights and biases.
        """
        ############################# STUDENT SOLUTION ####################
        # YOUR CODE HERE
        #     TODO:
        #         1) Set a seed so that your model is reproducible
        #         2) Initialize weight matrices and biases with uniform
        #         distribution in the range (-1, 1).
        rang = np.random.RandomState(seed=seed)
        a = rang.uniform(-1, 1, size=(hidden_size,vocab_size))
        b = rang.uniform(-1, 1, size=(hidden_size, input_size))
        c = rang.uniform(-1, 1, size=(num_classes, hidden_size))
        self.W = np.array(a, dtype=np.float64)
        self.b = np.array(b, dtype=np.float64)
        self.U = np.array(c, dtype=np.float64)

        ###################################################################

    def forward(self, X: npt.ArrayLike) -> npt.ArrayLike:
        """
        Forward pass with X as input matrix, returning the model prediction
        Y_hat.
        """
        ######################### STUDENT SOLUTION #########################
        # YOUR CODE HERE
        #     TODO:
        #         1) Perform only a forward pass with X as input.
        # Propogation to Hidden Layer
        z_at_hidden = np.add(np.matmul(self.W, X), self.b)  # weighted sum of input at hidden layer
        activation_at_hidden = relu(z_at_hidden)  # activation matrix at hidden layer

        # Propogation to output layer
        z_at_output = np.matmul(self.U, activation_at_hidden)  # weighted sum at output
        y_out = softmax(z_at_output)  # probability distribution over different intents for each example

        return y_out, z_at_hidden, activation_at_hidden

        #####################################################################

    def predict(self, X: npt.ArrayLike) -> npt.ArrayLike:
        """
        Create a prediction matrix with `self.forward()`
        """
        ######################### STUDENT SOLUTION ###########################
        # YOUR CODE HERE
        #     TODO:
        #         1) Create a prediction matrix of the intent data using
        #         `self.forward()` function. The shape of prediction matrix
        #         should be similar to label matrix produced with
        #         `labels_matrix()`
        y = self.forward(X)[0]  # predicted values
        return np.argmax(y, axis=0)  # predicted index (intent) of maximum value for each example

        ######################################################################

    def backward(
        self, 
        X: npt.ArrayLike, 
        Y: npt.ArrayLike, y_out, z_at_hidden, activation_at_hidden
    ) -> Tuple[npt.ArrayLike, npt.ArrayLike, npt.ArrayLike, npt.ArrayLike]:
        """
        Backpropagation algorithm.
        """
        ########################## STUDENT SOLUTION ###########################
        # YOUR CODE HERE
        #     TODO:
        #         1) Perform forward pass, then backpropagation
        #         to get gradient for weight matrices and biases
        #         2) Return the gradient for weight matrices and biases
        y_true = np.array(Y)
        del_error_at_out = y_out - y_true  # error term at output layer
        del_error_at_hidden = np.multiply(np.matmul(self.U.T, del_error_at_out),
                                          relu_prime(z_at_hidden))  # error term at hidden layer
        partial_change_in_weight_of_U = np.matmul(del_error_at_out,
                                                  activation_at_hidden.T)  # weights between hidden and output layer
        partial_change_in_weight_of_W = np.matmul(del_error_at_hidden, X.T)  # weights between input and hidden layer
        partial_change_in_bias = del_error_at_hidden  # bias for hidden layer neurons
        del_weight_of_U = partial_change_in_weight_of_U
        del_weight_of_W = partial_change_in_weight_of_W
        del_bias = partial_change_in_bias
        return (del_weight_of_U, del_weight_of_W, del_bias)

        #######################################################################


def compute_loss(pred: npt.ArrayLike, truth: npt.ArrayLike) -> float:
    """
    Compute the cross entropy loss.
    """
    ########################## STUDENT SOLUTION ###########################
    # YOUR CODE HERE
    #     TODO:
    #         1) Compute the cross entropy loss between your model prediction
    #         and the ground truth.
    y_true = np.array(truth)  # converting labelled example into numpy matrix

    # For every column vector in matrix of labelled example, we retrieve index of maximum value, which is 1 in this case,
    # This index corresponds to correct class for that particular example.
    true_index = np.argmax(y_true, axis=0)

    # Selecting only those predictions from each column which corresponds to correct class for that example. Since row
    # in y_out represent classes and column represent examples, so for every column we are choosing a row index from "true_index"
    # vector which contain row index of correct class.
    cost = np.sum(-np.log(pred[true_index, np.arange(y_true.shape[1])]))
    average_cost = cost / (pred.shape[1])
    return average_cost
    #######################################################################